const urlParams = new URLSearchParams(window.location.search);
const email = urlParams.get('email');

document.getElementById('email').textContent = email;

function redirectToSecondPage() {
const email = $('#form-1 [name="email"]').val();
location.href = `form2.html?email=${email}`;
}

document.getElementById('subscriptionForm').onsubmit = function(event) {
    var emailInput = document.querySelector('.email');
    if (!emailInput.value.includes('@')) {
      alert('Пожалуйста, введите корректный адрес электронной почты.');
      event.preventDefault();
    }
  };